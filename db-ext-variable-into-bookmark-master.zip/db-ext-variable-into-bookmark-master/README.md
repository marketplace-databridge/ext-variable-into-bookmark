# README #

This little extension is helping you to include variables into Bookmarks.

### Which Enigma methods are used? ###

* getVariableName
* getProperties
* setProperties

![alt text](https://github.com/pamaxeed/ql-ext-variable-bookmark/blob/master/qlVariableIntoBookmark.gif)
