define(['./src/visualization'], function(visualization) {
  return visualization;
});
